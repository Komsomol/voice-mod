**Voice Mod R&D**

Tech - https://github.com/alemangui/pizzicato

*Tasks*
- Capture voice
- Animate something with voice (Dummy)
- Modulate voice (Venom