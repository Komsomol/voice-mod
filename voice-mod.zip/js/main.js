//jshint esversion:6
// capture audio - done
// get amplitutde
// animate something to that amplitude
// animate only in voice range hz?

app = {
	button: document.querySelector("button"),
	// player: document.getElementById('player'),
	vol: document.querySelector(".vol"),

	init: () => {
		app.bindEvents();
	},

	bindEvents: () => {
		app.button.addEventListener("click", app.startRecord);

		app.button.addEventListener("tap", app.startRecord);
	},

	startRecord: () => {
		console.log("start to record");
		if (app.button.textContent === "Stop") {
			app.button.textContent = "Record";

			window.cancelAnimationFrame(app.animation);

			if (app.context) {
				app.context.close();
			}
		} else {
			navigator.mediaDevices
				.getUserMedia({ audio: true, video: false })
				.then(app.handleSuccess);
		}
	},

	handleSuccess: stream => {
		// app.context = new AudioContext();
		if (window.AudioContext) {
			console.log("chrome");
			app.context = new AudioContext();
		} else if (window.webkitAudioContext) {
			console.log("safari");
			app.context = new webkitAudioContext();
		}

		// app.audio = app.context.createMediaStreamSource(stream);
		// app.analyser = app.context.createAnalyser();

		// app.audio.connect(app.analyser);
		// this mutes the audio output
		// app.analyser.connect(app.context.destination);

		// app.analyser.fftSize = 1024;
		
		// app.bufferLength = app.analyser.frequencyBinCount;

		// app.dataArray = new Uint8Array(app.bufferLength);

		app.button.textContent = "Stop";

		var options = {
			onVoiceStart: function() {
				console.log('voice start');
			},
			onVoiceStop: function() {
				console.log('voice stop');
			},
			onUpdate: function(val) {
				console.log('curr val:', val);
				app.val = val * 100;
			}
		};

		
		vad(app.context, stream, options);


		app.animate();



	},

	animate: () => {
		app.animation = window.requestAnimationFrame(app.animate);

		app.vol.style.height = app.val + "px";
	}
};

window.onload = app.init();
